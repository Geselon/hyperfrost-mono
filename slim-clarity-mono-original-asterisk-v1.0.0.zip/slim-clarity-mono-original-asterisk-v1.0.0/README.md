# Slim Clarity Mono Original Asterisk

**Slim Clarity Mono Original Asterisk** is a customized, high-density variant of the Atkinson Hyperlegible Mono font family, tailored specifically for developers who prefer compact coding fonts while preserving the special readability of Atkinson Hyperlegible Mono.

## Features in this Package
- **Increased Code Density:** Squashed character width to fit more code horizontally on screen to match the proportions of JetBrains Mono and Fira Code.
- **Original Asterisk Alignment:** Retains the high-positioned asterisk shape from the original Atkinson Hyperlegible Mono design.

## Disclaimer & Credits
This project is a modified fork of Atkinson Hyperlegible Next Mono created by the Braille Institute. Slim Clarity Mono is an independent project. It is not affiliated with, sponsored by, or endorsed by the Braille Institute of America.

## License
This font is licensed under the **SIL Open Font License v1.1**. See the `OFL.txt` file for the full text.
